.. commit signature, "date_str author_str sha_str"
   Maintain spacing of "History" and "GitHub Log" titles

History
=======

GitHub Log
----------


* May 10, 2018
    - (by: sonofeft)
        - First Created EngCoolProp with PyHatch

